# Test 1
- Parent: 5, Left Child: 9, Right Child: 6;
- Parent: 9, Left Child: 10, Right Child: 84;
- Parent: 6, Left Child: 19, Right Child: 17;
- Parent: 10, Left Child: 22

# Test 2
- Parent: 5, Left Child: 9, Right Child: 6;
- Parent: 9, Left Child: 10, Right Child: 84;
- Parent: 6, Left Child: 19, Right Child: 17;
- Parent: 10, Left Child: 22

# Test 3
- Parent: 5, Left Child: 8, Right Child: 6;
- Parent: 8, Left Child: 10, Right Child: 88;
- Parent: 6, Left Child: 19, Right Child: 16;
- Parent: 10, Left Child: 22
