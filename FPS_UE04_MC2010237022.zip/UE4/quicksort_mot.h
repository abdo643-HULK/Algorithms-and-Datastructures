//
// Created by Abdo on 04.11.21.
//

#ifndef UE3_QUICKSORT_MOT_H
#define UE3_QUICKSORT_MOT_H

void quicksort_mot(int array[], int size, int left, int right);

#endif //UE3_QUICKSORT_MOT_H
